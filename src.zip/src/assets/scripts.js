      var service ="";
      var myLocation;
      var rate = 0;
      var currancy="";
      var car="";
       var back={  "direction"        : "right", // 'left|right|up|down', default 'left' (which is like 'next')
            "slowdownfactor"   :    2, // overlap views (higher number is more) or no overlap (1). -1 doesn't slide at all. Default 4
            "fixedPixelsTop"   :    0, // the number of pixels of your fixed header, default 0 (iOS and Android)
            "duration":300
      };
             var next={  "direction"        : "left", // 'left|right|up|down', default 'left' (which is like 'next')
            "slowdownfactor"   :    2, // overlap views (higher number is more) or no overlap (1). -1 doesn't slide at all. Default 4
            "fixedPixelsTop"   :    0, // the number of pixels of your fixed header, default 0 (iOS and Android)
             "duration":300
      };